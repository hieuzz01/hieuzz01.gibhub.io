1. Link web
https://github.com/tuandtvt/KTPMUD

2. Tài khoản các loại user

   Tài khoản admin: admin    mật khẩu: 123456

   Tài khoản user:  tuan12345  mật khẩu: tuan12345

3. Link github
https://github.com/tuandtvt/KTPMUD

4. Hướng dẫn cài đặt

5. Link Wordpress 
https://et3260.wordpress.com/2022/11/11/nhom-20-project/
